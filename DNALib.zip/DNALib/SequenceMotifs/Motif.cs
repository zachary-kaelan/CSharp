﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNALib.SequenceMotifs
{
    public class Motif
    {
        internal MotifOp[] Code { get; set; }
        internal int MinimumSequenceLength = 0;
        internal SortedDictionary<int, Func<DNACodon, bool>> Delegates = new SortedDictionary<int, Func<DNACodon, bool>>();

        public Motif(string str)
        {
            ParseMotif(str);
        }

        private static readonly SortedSet<char> OPEN_GROUP = new SortedSet<char>() { '[', '{' };
        private static readonly SortedSet<char> CLOSE_GROUP = new SortedSet<char>() { ']', '{' };

        private void ParseMotif(string str)
        {
            List<MotifOp> code = new List<MotifOp>();
            if (str.Contains('-'))
            {
                var fragments = str.Split('-');
                foreach (var fragment in fragments)
                    ParseFragment(fragment, code);
            }
            else
                ParseFragment(str, code);
            Code = code.ToArray();
        }

        private void ParseFragment(string str, List<MotifOp> code)
        {
            int length = str.Length;
            for (int i = 0; i < length; ++i)
            {
                DNACodon val = DNACodon.NIL;
                char chr = str[i];
                if (OPEN_GROUP.Contains(chr))
                {
                    char open = chr;
                    List<char> chars = new List<char>();
                    ++i;
                    chr = str[i];
                    do
                    {
                        chars.Add(chr);
                        val |= MotifConstants.CODON_CHARS[chr];
                        ++i;
                        chr = str[i];
                    } while (!CLOSE_GROUP.Contains(chr));

                    MotifCode temp = MotifCode.NIL;

                    temp |= chars.Count == 1 ? MotifCode.One : MotifCode.Set;
                    if (chr == ']')
                        temp |= MotifCode.Not;

                    if (TryGetRange(str.Substring(i + 1), out int lower, out int upper))
                    {
                        MinimumSequenceLength += lower;
                        temp |= MotifCode.Loop;
                        var op = new MotifOp(temp, val, lower, upper);
                        code.Add(op);
                        AddDelegate(code.Count - 1, op);
                        i = str.IndexOf(')', i + 3);
                    }
                    else
                    {
                        ++MinimumSequenceLength;
                        code.Add(new MotifOp(temp, val, -1, -1));
                    }
                }
                else
                {
                    ++MinimumSequenceLength;
                    if (chr == 'x')
                        code.Add(new MotifOp(MotifCode.Skip, DNACodon.NIL, -1, -1));
                    else if (MotifConstants.CODON_CHARS.TryGetValue(chr, out val))
                        code.Add(new MotifOp(MotifCode.One, val, -1, -1));
                    else
                        throw new FormatException("Motif pattern is in an invalid format.");
                }
            }
        }

        private static bool TryGetRange(string str, out int lower, out int upper)
        {
            char chr = str[0];
            lower = -1;
            upper = -1;
            if (chr == '(')
            {
                List<char> numberChars = new List<char>();
                for (int i = 1; i < str.Length; ++i)
                {
                    chr = str[i];
                    if (Char.IsDigit(chr))
                        numberChars.Add(chr);
                    else
                    {
                        int bound = numberChars.Count == 1 ?
                            Convert.ToInt32(Char.GetNumericValue(numberChars[0])) :
                            Convert.ToInt32(new string(numberChars.ToArray()));
                        if (lower == -1)
                            lower = bound;
                        else
                        {
                            upper = bound;
                            return true;
                        }
                        if (chr == ',')
                            numberChars.Clear();
                        else
                            return true;
                    }
                }
                return false;
            }
            else
                return false;
        }

        private void AddDelegate(int index, MotifOp op)
        {
            bool not = op.Code.HasFlag(MotifCode.Not);
            Func<DNACodon, bool> func = null;
            if(op.Code.HasFlag(MotifCode.One))
            {
                if (not)
                    func = c => op.Value != c;
                else
                    func = c => op.Value == c;
            }
            else
            {
                if (not)
                    func = c => !op.Value.HasFlag(c);
                else
                    func = c => op.Value.HasFlag(c);
            }
            Delegates.Add(index, func);
        }
    }
}
