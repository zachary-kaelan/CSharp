﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNALib.SequenceMotifs
{
    internal class MotifRunner
    {
        private int Length { get; set; }
        private Func<Motif> GetMotif;
        private Func<AminoAcid> GetSequence;
        private List<DNACodon> Sequence;
        private int LastCodeIndex { get; set; }

        private int CodeIndex = -1;
        private int SequenceIndex = 0;
        private MotifOp CurrentOp { get; set; }
        private Func<DNACodon, bool> CurrentOpFunc = null;

        private int CurrentOpMatches = 0;
        private bool IsLooping = false;

        // the remaining minimum code length
        private int RemainingLength { get; set; }
        private int Marker = -1;
        private List<MotifMatch> Matches = new List<MotifMatch>();

        public MotifRunner(Motif motif, AminoAcid sequence)
        {
            Length = sequence.Count;
            LastCodeIndex = motif.Code.Length - 1;
            RemainingLength = Length;
            GetMotif = () => motif;
            GetSequence = () => sequence;
        }

        private bool Run(int startIndex, int count, int maxMatches)
        {
            var motif = GetMotif();
            if (Length < motif.MinimumSequenceLength)
                return false;

            bool doCount = count < Length - startIndex;
            bool doStartIndex = startIndex > 0 && startIndex < Length - 1;
            IncrementCodeIndex();

            Sequence = (doStartIndex || doCount ? (
                        doStartIndex && doCount ?
                            GetSequence().Skip(startIndex).Take(count) : (
                                doStartIndex ?
                                    GetSequence().Skip(startIndex) :
                                    GetSequence().Take(count)
                            )
                    ) : GetSequence()).ToList();

            for (int i = 0; i < Length; ++i)
            {
                //var op = Code[codeIndex];
                
            }
        }

        private bool Go(Motif motif, int opIndex, int startIndex, int remainingLength)
        {

        }

        private bool Loop(Motif motif, int opIndex, int startIndex, int remainingLength)
        {
            var func = motif.Delegates[opIndex];
            int initialRemainingLength = remainingLength;
            int opMatches = 0;
            var op = motif.Code[opIndex];
            int minFinalIndex = startIndex + op.Lower;

            bool isMatch = true;
            DNACodon currentCodon = DNACodon.NIL;
            for (int i = startIndex; isMatch && i <= minFinalIndex; ++i)
            {
                currentCodon = Sequence[i];
                if (!func(currentCodon))
                    isMatch = false;
            }

            if (isMatch)
            {
                // if a range instead of a set count
                if (op.Upper != -1)
                {
                    // doesn't bother running ranges that leave insufficient length for remaining code
                    // remainingLength includes the lower bound of this loop op
                    int maxFinalIndex = Math.Min(startIndex + op.Upper, startIndex + remainingLength);
                    int index;
                    bool nextIsLoop = motif.Code[opIndex + 1].Code.HasFlag(MotifCode.Loop);
                    isMatch = false;

                    // potential range includes the previously-confirmed match at the end of the lower bound

                    // sets the index to the maximum of the range
                    for (index = minFinalIndex; func(currentCodon) && index <= maxFinalIndex; ++index) { }

                    if (opIndex == LastCodeIndex)
                    {
                        EndMatch(index);
                        return true;
                    }

                    for (; index >= minFinalIndex; --index) // greedy by default
                    {
                        // forbids matches from being subsequences of each other by default
                        if (nextIsLoop)
                        {
                            if (
                                Loop(
                                    motif,
                                    opIndex + 1,
                                    index + 1,
                                    remainingLength - (index - startIndex)
                                )
                            )
                                return true;
                        }
                        else
                        {
                            if (
                                Go(
                                    motif,
                                    opIndex + 1,
                                    index + 1,
                                    remainingLength - (index - startIndex)
                                )
                            )
                                return true;
                        }
                    }
                }
                else if (opIndex == LastCodeIndex)
                {
                    EndMatch(minFinalIndex);
                    return true;
                }
            }
            
            return isMatch;
        }

        private void EndMatch(int endIndex)
        {
            int count = endIndex - SequenceIndex;
            Matches.Add(
                new MotifMatch(
                    SequenceIndex,
                    count,
                    Sequence.GetRange(SequenceIndex, count).ToArray()
                )
            );
        }

        private bool IsOpMatch(int opIndex, DNACodon codon)
        {
            bool isCurrentOp = opIndex == -1;
            var op = isCurrentOp ? CurrentOp : GetMotif().Code[opIndex];
            if (op.Code.HasFlag(MotifCode.Loop))
            {
                if ((IsLooping ? CurrentOpFunc : GetMotif().Delegates[opIndex])(codon))
                {
                    ++CurrentOpMatches;
                    return true;
                }
                return false;
            }

            bool result = op.Code.HasFlag(MotifCode.One) ?
                codon == op.Value :
                op.Value.HasFlag(codon);
            return op.Code.HasFlag(MotifCode.Not) ?
                !result : result;
        }

        private void IncrementCodeIndex()
        {
            var motif = GetMotif();
            ++CodeIndex;
            CurrentOp = motif.Code[CodeIndex];
            CurrentOpMatches = 0;
            CurrentOpFunc = null;
            if (CurrentOp.Code.HasFlag(MotifCode.Loop))
            {
                CurrentOpFunc = motif.Delegates[CodeIndex];
                IsLooping = true;
            }
        }
    }
}
