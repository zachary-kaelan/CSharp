﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNALib.SequenceMotifs
{
    public class MotifMatch
    {
        public int Index { get; private set; }
        public int Length { get; private set; }
        public DNACodon[] Value { get; private set; }

        internal MotifMatch(int index, int length, DNACodon[] value)
        {
            Index = index;
            Length = length;
            Value = value;
        }
    }
}
