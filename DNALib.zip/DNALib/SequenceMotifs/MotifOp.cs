﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNALib.SequenceMotifs
{
    internal struct MotifOp
    {
        public MotifCode Code { get; set; }
        public DNACodon Value { get; set; }
        public int Lower { get; set; }
        public int Upper { get; set; }

        public MotifOp(MotifCode code, DNACodon codon, int lower, int upper)
        {
            Code = code;
            Value = codon;
            Lower = lower;
            Upper = upper;
        }
    }
}
