﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNALib
{
    [Flags]
    public enum Nucleotide : byte
    {
        Zero = 0,
        Adenine = 1,
        Cytosine = 2,
        Guanine = 4,
        Thymine = 8,
        Purine = Guanine | Adenine,
        Pyrmidine = Thymine | Cytosine,
        Keto = Guanine | Thymine,
        Amino = Adenine | Cytosine,
        Strong_Bonds = Guanine | Cytosine,
        Weak_Bonds = Adenine | Thymine,
        Not_A = Guanine | Thymine | Cytosine,
        Not_C = Guanine | Adenine | Thymine,
        Not_G = Adenine | Cytosine | Thymine,
        Not_T = Guanine | Cytosine | Adenine,
        Any = Adenine | Guanine | Cytosine | Thymine
    }

    public enum AminoProperties : byte
    {
        Nonpolar,
        Polar,
        Basic,
        Acidic,
        Start_Nonpolar = 4,
        Stop = 8
    }
    
    public enum DNACodon
    {
        NIL = 0,
        Phe = 1,
        Leu = 2,
        Ile = 4,
        Met = 8,
        Val = 16,

        Ser = 32,
        Pro = 64,
        Thr = 128,
        Ala = 256,

        Och = 512,
        Amb = 1024,
        His = 2048,
        Gln = 4096,
        Asn = 8192,
        Lys = 16384,
        Asp = 32768,
        Glu = 65536,

        Cys = 131072,
        Opl = 262144,
        Trp = 524288,
        Arg = 1048576,
        Gly = 2097152
    }

    public static class Constants
    {
        public const string NUCLEOTIDE_LETTERS = "ZACMGRSVTWYHKDBN";

        // Amber is J for Jurassic World
        // Ochre is O
        // Opal is U for Umber
        public const string CODON_LETTERS =
        //         T        C        A        G
        /*T*/    "FFLL" + "LLLL" + "IIIM" + "VVVV" +
        /*C*/    "SSSS" + "PPPP" + "TTTT" + "AAAA" +
        /*A*/    "YYOJ" + "HHQQ" + "NNKK" + "DDEE" +
        /*G*/    "CCUW" + "RRRR" + "SSRR" + "GGGG";
        //        TCAG     TCAG     TCAG     TCAG

        public static readonly SortedDictionary<Nucleotide, Nucleotide> COMPLEMENTS = new SortedDictionary<Nucleotide, Nucleotide>()
        {
            { Nucleotide.Adenine, Nucleotide.Thymine },
            { Nucleotide.Cytosine, Nucleotide.Guanine},
            { Nucleotide.Guanine, Nucleotide.Cytosine },
            { Nucleotide.Thymine, Nucleotide.Adenine },
            { Nucleotide.Weak_Bonds, Nucleotide.Weak_Bonds },
            { Nucleotide.Strong_Bonds, Nucleotide.Strong_Bonds },
            { Nucleotide.Amino, Nucleotide.Keto },
            { Nucleotide.Keto, Nucleotide.Amino },
            { Nucleotide.Purine, Nucleotide.Pyrmidine },
            { Nucleotide.Pyrmidine, Nucleotide.Purine },
            { Nucleotide.Not_A, Nucleotide.Not_T },
            { Nucleotide.Not_C, Nucleotide.Not_G },
            { Nucleotide.Not_G, Nucleotide.Not_C },
            { Nucleotide.Not_T, Nucleotide.Not_A },
            { Nucleotide.Any, Nucleotide.Any },
            { Nucleotide.Zero, Nucleotide.Zero }
        };
    }
}
