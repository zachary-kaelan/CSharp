﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingTestQuestions1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("How many games do you want to play? ");
            int numGames = Convert.ToInt32(Console.ReadLine());
            int jackwon = 0;
            int jillwon = 0;
            for(int i = 0; i < numGames; ++i)
            {
                try
                {
                    Console.Write("What is Jack's choice? ");
                    int jack = Convert.ToInt32(Console.ReadLine());
                    Console.Write("What is Jill's choice? ");
                    int jill = Convert.ToInt32(Console.ReadLine());

                    if (jack == jill)
                    {
                        Console.WriteLine("Nobody wins");
                        --i;
                    }
                    else if ((jack == 1 && jill == 2) || (jack == 2 && jill == 3) || (jack == 3 && jill == 1))
                    {
                        Console.WriteLine("Jack wins");
                        ++jackwon;
                    }
                    else
                    {
                        Console.WriteLine("Jill wins");
                        ++jillwon;
                    }
                        
                }
                catch
                {
                    Console.WriteLine("Invalid input");
                    --i;
                }
            }

            if (jillwon > jackwon)
                Console.WriteLine("Jill won more games");
            else if (jackwon > jillwon)
                Console.WriteLine("Jack won more games");
            else
                Console.WriteLine("They have won the same number of games.");

            Console.WriteLine("Press any key to continue...");
            Console.Read();
        }
    }
}
